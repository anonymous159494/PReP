from openai import OpenAI

OPENAI_KEY = 'your-openai-api-key'
LLAMA_KEY = 'your-llama-api-key'

MODEL_API_CONFIG = {
    "openai": {
        "base_url": "https://api3.apifans.com/v1",
        "model": "gpt-3.5-turbo",
        "api_key": OPENAI_KEY,
        "client": OpenAI,
    },
    "qwen": {
        "base_url": "http://0.0.0.0:7667/v1",  # 假设Qwen的API地址
        "model": "xxx",
        "api_key": 'EMPTY',
        "client": OpenAI,
    },
    "llama": {
        "base_url": "https://api.siliconflow.cn/v1/chat/completions",  # 假设Llama的API地址
        "model": "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "api_key": LLAMA_KEY,
    },
    "llama_local": {
        "base_url": "http://0.0.0.0:8000/v1",  # 假设Llama的API地址
        "model": "xxxx",
        "api_key": 'EMPTY',
        "client": OpenAI,
    },
    "llama_FT": {
        "base_url": 'http://0.0.0.0:8000/v1',  # 假设Llama的API地址
        "model": "xxx",
        "api_key": 'EMPTY',
        "client": OpenAI,
    }
}
