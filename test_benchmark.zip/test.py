import json
from openai import OpenAI
import time
from collections import defaultdict
import httpx
import requests
import argparse
from tqdm import tqdm
import re
import os
from model_config import MODEL_API_CONFIG
from utils import load_test_data, save_results, build_prompt,evaluate_answer
from datetime import datetime

def get_model_answer(messages, model_name, max_retries=3, retry_delay=2):
    model_config = MODEL_API_CONFIG.get(model_name)
    if not model_config:
        print(f"Model '{model_name}' is not supported.")
        return None

    retries = 0
    while retries < max_retries:
        try:
            client = model_config["client"](
                api_key=model_config["api_key"],
                base_url=model_config["base_url"]
            )
            response = client.chat.completions.create(
                model=model_config["model"],
                messages=messages,
            )
            model_answer = response.choices[0].message.content.strip()
            return model_answer
        
        except Exception as e:
            print(f"Error during model inference with {model_name}: {e}. Retrying... ({retries + 1}/{max_retries})")
            retries += 1
            time.sleep(retry_delay)  # 等待一段时间后重试

    print(f"Failed to get response from {model_name} after {max_retries} retries.")
    return None

# 运行评测任务
def run_evaluation(test_data, output_file, model_name, dataset):
    correct_count = 0
    total_count = len(test_data)
    errors = defaultdict(int)
    results = []

    for idx, item in tqdm(enumerate(test_data), total=len(test_data), desc="Processing test data"):
        observation = item.get("observation")
        question = item.get("question")
        correct_answer = item.get("answer")
        source = item.get("source")
        
        # 构建系统消息和用户消息
        messages = build_prompt(observation, question, dataset)
        model_answer = get_model_answer(messages, model_name)

        # 如果没有得到模型答案，跳过该项
        if model_answer is None:
            errors["No Response"] += 1
            results.append({
                "observation": observation,
                "question": question,
                "correct_answer": correct_answer,
                "model_answer": model_answer,
                "source": source,
                "status": "No Response"
            })
            continue

        # 评估答案并统计正确与否
        is_correct = evaluate_answer(model_answer, correct_answer, dataset)
        if is_correct:
            correct_count += 1
            status = "Correct"
        else:
            errors["Incorrect Answer"] += 1
            status = "Incorrect"
        
        results.append({
            "observation": observation,
            "question": question,
            "correct_answer": correct_answer,
            "model_answer": model_answer,
            "source": source,
            "status": status
        })
    
    accuracy = correct_count / total_count if total_count > 0 else 0
    print(f"Evaluation Results: Accuracy: {accuracy:.2%}")
    print(f"Errors: {dict(errors)}")
    
    # 保存结果
    save_results(results, output_file)
    
    return accuracy, errors

# 主程序
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="选择模型和数据类型")

    # 添加命令行参数
    parser.add_argument('--model_name', type=str, choices=["openai", "llama", "llama_FT", "llama_local", "qwen"],
                        default="llama_local", help="选择使用的模型名称")
    parser.add_argument('--data_type', type=str, choices=["clean", "noise", "sampled"],
                        default="", help="选择数据类型") ## 主要针对stepgame数据集
    parser.add_argument('--dataset', type=str, choices=["cogmap", "stepgame"],
                        default="stepgame", help="选择数据类型")

    # 解析命令行参数
    args = parser.parse_args()
    if args.data_type != "" and args.dataset == "stepgame":
        args.data_type = args.data_type + "_"
    current_time = datetime.now().strftime("%m-%d_%H-%M")
    test_file = f"./{args.dataset}/structured_data/{args.data_type}test_data.json"
    output_file = f"./results/{args.dataset}_{args.model_name}_{args.data_type}results_{current_time}.json"  # 保存结果的文件路径
    
    test_data = load_test_data(test_file)
    
    if test_data:
        accuracy, errors = run_evaluation(test_data, output_file, args.model_name, args.dataset)
    else:
        print("No test data to evaluate.")
