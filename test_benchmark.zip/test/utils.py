import os
import time
import jsonlines
from openai import OpenAI
import json
from collections import defaultdict
import requests
import re
# from constant import PLATFORM, API_KEY_MAP, BASE_URL_MAP 


def load_test_data(test_file):
    try:
        with open(test_file, "r", encoding="utf-8") as f:
            test_data = json.load(f)
        return test_data[:]
    except Exception as e:
        print(f"Error loading test file: {e}")
        return []

def save_results(results, output_file):
    try:
        output_dir = os.path.dirname(output_file)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)

        # 保存结果到 JSON 文件
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=4, ensure_ascii=False)
        print(f"Results saved to {output_file}")
    except Exception as e:
        print(f"Error saving results: {e}")

def extract_answer(model_answer):
    
    # 使用正则表达式提取 'Answer: ' 后的内容
    match = re.search(r"Answer: (.*)", model_answer.strip())  # 提取 'Answer: ' 后的内容
    if match:
        return match.group(1).strip()  # 返回匹配的 'Answer: ' 部分及其后的内容
    
    return None  # 如果没有匹配到 'Answer: '，返回 None

def evaluate_answer(model_answer, correct_answers, datasets = "stepgame"):
    if datasets == "stepgame":
        # 定义所有的完整方位词（包括复合方位词）
        directions = ['lower-left', 'below', 'above', 'upper-right', 'lower-right', 'right', 'upper-left', 'left', 'overlap']
        
        # 标准化输入：去除空格，转小写
        model_answer = model_answer.strip().lower()
        correct_answer = correct_answers.strip().lower()

        # 提取模型回答中的方位词（包括复合方位词和单一方位词）
        words_in_model_answer = []

        # 先匹配复合方位词（如 'lower-left'）
        for direction in directions:
            if direction in model_answer:
                words_in_model_answer.append(direction)
        
        # 如果模型答案中存在方位词，且正确答案包含在其中
        if words_in_model_answer:
            # 如果模型答案和正确答案完全匹配
            if len(words_in_model_answer) == 1 and words_in_model_answer[0] == correct_answer:
                return True
            
            # 如果有多个方位词，允许部分匹配
            if correct_answer in words_in_model_answer:
                return True
        
        return False

    elif datasets == "cogmap":
        # 提取模型回答中的 'Answer: ' 后的部分
        extracted_answer = extract_answer(model_answer)
        # print(f"Extracted Answer: {extracted_answer}")
        
        if not extracted_answer:
            print(f"Model answer does not contain a valid 'Answer: ' prefix.")
            return False

        # 分词：按逗号分隔模型答案
        model_answer_parts = [part.strip().lower() for part in extracted_answer.split(",")]

        # 标准化正确答案：按逗号分隔并转换为小写
        correct_answers_parts = []
        for correct_answer in correct_answers:
            extracted_correct_answer = extract_answer(correct_answer)
            if extracted_correct_answer:
                correct_answers_parts.append([part.strip().lower() for part in extracted_correct_answer.split(",")])

        # 顺序匹配：模型答案中的每个元素必须按顺序在正确答案中找到，且支持部分匹配
        for correct_answer_parts in correct_answers_parts:
            it = iter(model_answer_parts)
            if all(any(part in model_part for model_part in it) for part in correct_answer_parts):
                return True

        return False

    else:
        return False

def build_prompt(observation, question, datasets = "stepgame"):
    if datasets == "stepgame":
        system_message = (
            "Your task is to answer questions about the spatial relationship based on the observation."
            " Your answer should strictly be one of the following relations based on the relative spatial position:"
            "lower-left, below, above, upper-right, lower-right, right, upper-left, left."
            " Do not provide any other answer."
        )
        
        user_message = f"Observation: {observation}\nQuestion: {question}\nAnswer:"

        return [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_message}
        ]
    elif datasets == "cogmap":
        system_message = question
        if len(observation) == 1:
            # 情况 1: observation 只有一条
            user_message = observation[0]
            return [
                {"role": "user", "content": user_message + system_message}
            ]
        elif len(observation) == 2:
            # 情况 2: observation 有两条，进行两轮对话
            first_user_message = observation[0]
            second_user_message = observation[1]
            
            return [
                {"role": "user", "content": first_user_message},
                {"role": "user", "content": second_user_message+system_message},
            ]
        return []
    else:
        return []
  
# class LLM:
#     """
#     The language model class for generating text using different platforms.

#     Args:
#         model_name (str): The name of the model.
#         platform (PLATFORM): The platform to use.

#     Attributes:
#         model_name (str): The name of the model.
#         platform (PLATFORM): The platform to use.
#         client (openai.Client): The OpenAI client.
#         completion_tokens (int): The number of tokens used for completion.
#         prompt_tokens (int): The number of tokens used for prompt.

#     Methods:
#         generate: Generate text based on the prompt.
#         clear_history: Clear the history of generated text.
#         save_history: Save the history of generated text to a file.
    
#     """
#     def __init__(self, model_name: str, platform: PLATFORM = 'openai', api_key: str = None):
#         """
#         Initializes an instance of the class.

#         Args:
#             model_name (str): The name of the model.
#             platform (PLATFORM, optional): The platform to use. Defaults to 'openai'.
#             api_key (str, optional): The API key for the platform. Defaults to None (use the environment variable).
#         """
#         self.model_name = model_name
#         self.platform = platform
#         self.api_key = api_key
        
#         self.client = self._init_client(platform)

#         self.completion_tokens = 0
#         self.prompt_tokens = 0
#         self.history = []

#     def _init_client(self, platform: PLATFORM):
#         """
#         Initialize the OpenAI client with the API key and base URL.

#         Args:
#             platform (PLATFORM): The platform to use.
        
#         Returns:
#             openai.Client: The OpenAI client.
#         """
#         assert platform in API_KEY_MAP, f"Platform {platform} is not supported."
#         if self.api_key:
#             api_key = self.api_key
#         else:
#             api_key = os.environ.get(API_KEY_MAP[platform])
#         assert api_key, f"API key for platform {platform} is not found."
#         base_url = BASE_URL_MAP[platform]
#         client = OpenAI(
#             api_key=api_key, 
#             base_url=base_url
#         )
#         return client

#     def generate(
#         self, 
#         prompt: list[dict]|str, 
#         model:str|None = None, 
#         temperature: float = 1.0, 
#         max_tokens: int = 4096
#     ):
#         """
#         Generate text based on the prompt.

#         Args:
#             prompt (str): The prompt for the model.
#             model (str|None): The model to use. If None, use the default model.
#             temperature (float): The temperature for sampling.
#             max_tokens (int): The maximum number of tokens to generate.
        
#         Returns:
#             str: The generated text.
#         """
#         if model is None:
#             model = self.model_name

#         if isinstance(prompt, str):
#             messages = [{'role': 'user', 'content': prompt}]
#         else:
#             messages = prompt

#         # save system time when log history
#         for m in messages:
#             m.update({"time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())})
#             self.history.append(m)

#         completion = self.client.chat.completions.create(
#             model=model,
#             messages=messages,
#             max_tokens=max_tokens,
#             temperature=temperature
#         )
#         self.completion_tokens += completion.usage.completion_tokens
#         self.prompt_tokens += completion.usage.prompt_tokens

#         response = completion.choices[0].message.content
#         self.history.append({'role': 'assistant', 'content': response, 'time': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())})

#         return response

#     def clear_history(self):
#         """
#         Clear the history of generated text.
#         """
#         self.history = []

#     def save_history(self, path: str):
#         """
#         Save the history of generated text to a file.

#         Args:
#             path (str): The path to save the history.
#         """
#         with jsonlines.open(path, 'w') as writer:
#             for item in self.history:
#                 writer.write(item)

#     def __repr__(self):
#         return f"LLM(model_name={self.model_name}, platform={self.platform})"



