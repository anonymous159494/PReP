import json
from openai import OpenAI
import time
from collections import defaultdict
import httpx
import requests
import argparse
from tqdm import tqdm
import re
# 设置API Key
OPENAI_KEY = "sk-g55N3fVgL2ZpS0od9b1f88FaD05443269b1a664746698038"
QWEN_KEY = "sk-vqjefeuhhaqrfskiqqhabdsoofhjqniioeockrhuvtgwdyyn"
LLAMA_KEY = "sk-vqjefeuhhaqrfskiqqhabdsoofhjqniioeockrhuvtgwdyyn"

# API配置
MODEL_API_CONFIG = {
    "openai": {
        "base_url": "https://api3.apifans.com/v1",
        "model": "gpt-3.5-turbo",
        "api_key": OPENAI_KEY,
        "client": OpenAI,
    },
    "qwen": {
        "base_url": "https://api.siliconflow.cn/v1/chat/completions",  # 假设Qwen的API地址
        "model": "Qwen/Qwen2-VL-72B-Instruct",
        "api_key": QWEN_KEY,
    },
    "llama": {
        "base_url": "https://api.siliconflow.cn/v1/chat/completions",  # 假设Llama的API地址
        "model": "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "api_key": LLAMA_KEY,
    },
    "llama_local": {
        "base_url": "http://0.0.0.0:8001/v1",  # 假设Llama的API地址
        "model": "/home/zengqingbin/.cache/modelscope/hub/LLM-Research/Meta-Llama-3.1-8B-Instruct",
        "api_key": 'EMPTY',
        "client": OpenAI,
    },
    "llama_FT": {
        "base_url": 'http://0.0.0.0:8000/v1',  # 假设Llama的API地址
        "model": "/home/zengqingbin/.cache/modelscope/hub/LLM-Research/Meta-Llama-3.1-8B-Instruct",
        "api_key": 'EMPTY',
        "client": OpenAI,
    }
}

def load_test_data(test_file):
    try:
        with open(test_file, "r", encoding="utf-8") as f:
            test_data = json.load(f)
        return test_data
    except Exception as e:
        print(f"Error loading test file: {e}")
        return []

# 构建大语言模型提示（prompt）
def build_prompt(observation, question):


    system_message = (
        "Your task is to answer questions about the spatial relationship based on the observation."
        " Your answer should strictly be one of the following relations based on the relative spatial position:"
        "lower-left, below, above, upper-right, lower-right, right, upper-left, left."
        " Do not provide any other answer."
    )
    
    user_message = f"Observation: {observation}\nQuestion: {question}\nAnswer:"

    return [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message}
    ]

# 通用函数，根据模型名称调用不同的API
def get_model_answer(messages, model_name, max_retries=3, retry_delay=2):
    model_config = MODEL_API_CONFIG.get(model_name)
    
    if not model_config:
        print(f"Model '{model_name}' is not supported.")
        return None

    retries = 0
    while retries < max_retries:
        try:
            if model_name == "openai":
                # OpenAI API调用
                client = model_config["client"](
                    api_key=model_config["api_key"],
                    base_url=model_config["base_url"]
                )
                response = client.chat.completions.create(
                    model=model_config["model"],
                    messages=messages,
                    max_tokens=100,
                    temperature=0.0,
                )
                model_answer = response.choices[0].message.content.strip()

            elif model_name == "qwen":
                # Qwen API调用
                headers = {"Authorization": f"Bearer {model_config['api_key']}"}
                data = {
                    "model": model_config["model"],
                    "messages": messages,
                    "temperature": 0.0
                }
                response = requests.post(
                    f"{model_config['base_url']}",
                    json=data,
                    headers=headers
                )
                response.raise_for_status()  # 检查请求是否成功
                model_answer = response.json().get("choices", [{}])[0].get("message", {}).get("content", "").strip()

            elif model_name == "llama":
                # Llama API调用
                headers = {"Authorization": f"Bearer {model_config['api_key']}"}
                data = {
                    "model": model_config["model"],
                    "messages": messages,
                    "temperature": 0.5
                }
                response = requests.post(
                    f"{model_config['base_url']}",
                    json=data,
                    headers=headers
                )
                response.raise_for_status()  # 检查请求是否成功
                model_answer = response.json().get("choices", [{}])[0].get("message", {}).get("content", "").strip()
            elif model_name == "llama_local":

                client = model_config["client"](
                    api_key=model_config["api_key"],
                    base_url=model_config["base_url"]
                )
                response = client.chat.completions.create(
                    model=model_config["model"],
                    messages=messages,
                )
                model_answer = response.choices[0].message.content.strip()
            elif model_name == "llama_FT":

                client = model_config["client"](
                    api_key=model_config["api_key"],
                    base_url=model_config["base_url"]
                )
                response = client.chat.completions.create(
                    model=model_config["model"],
                    messages=messages,
                )
                model_answer = response.choices[0].message.content.strip()
            return model_answer
        
        except Exception as e:
            print(f"Error during model inference with {model_name}: {e}. Retrying... ({retries + 1}/{max_retries})")
            retries += 1
            time.sleep(retry_delay)  # 等待一段时间后重试

    print(f"Failed to get response from {model_name} after {max_retries} retries.")
    return None
# 评估模型回答
def evaluate_answer(model_answer, correct_answer):
    # 定义所有的完整方位词（包括复合方位词）
    directions = ['lower-left', 'below', 'above', 'upper-right', 'lower-right', 'right', 'upper-left', 'left', 'overlap']
    
    # 标准化输入：去除空格，转小写
    model_answer = model_answer.strip().lower()
    correct_answer = correct_answer.strip().lower()

    # 提取模型回答中的方位词（包括复合方位词和单一方位词）
    words_in_model_answer = []

    # 先匹配复合方位词（如 'lower-left'）
    for direction in directions:
        if direction in model_answer:
            words_in_model_answer.append(direction)
    
    # 如果模型答案中存在方位词，且正确答案包含在其中
    if words_in_model_answer:
        # 如果模型答案和正确答案完全匹配
        if len(words_in_model_answer) == 1 and words_in_model_answer[0] == correct_answer:
            return True
        
        # 如果有多个方位词，允许部分匹配
        if correct_answer in words_in_model_answer:
            return True
    
    return False

# 保存结果到文件
def save_results(results, output_file):
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=4, ensure_ascii=False)
        print(f"Results saved to {output_file}")
    except Exception as e:
        print(f"Error saving results: {e}")

# 运行评测任务
def run_evaluation(test_data, output_file, model_name):
    correct_count = 0
    total_count = len(test_data)
    errors = defaultdict(int)
    results = []

    for idx, item in tqdm(enumerate(test_data), total=len(test_data), desc="Processing test data"):
        # time.sleep(2)  # 避免请求过于频繁   
        observation = item.get("observation")
        question = item.get("question")
        correct_answer = item.get("answer")
        source = item.get("source")
        
        # 构建系统消息和用户消息
        messages = build_prompt(observation, question)
        model_answer = get_model_answer(messages,model_name)

        
        # 如果没有得到模型答案，跳过该项
        if model_answer is None:
            errors["No Response"] += 1
            results.append({
                "observation": observation,
                "question": question,
                "correct_answer": correct_answer,
                "model_answer": model_answer,
                "source": source,
                "status": "No Response"
            })
            continue
        
        # 评估答案并统计正确与否
        is_correct = evaluate_answer(model_answer, correct_answer)
        if is_correct:
            correct_count += 1
            status = "Correct"
        else:
            errors["Incorrect Answer"] += 1
            status = "Incorrect"
        
        results.append({
            "observation": observation,
            "question": question,
            "correct_answer": correct_answer,
            "model_answer": model_answer,
            "source": source,
            "status": status
        })
    
    accuracy = correct_count / total_count if total_count > 0 else 0
    print(f"Evaluation Results: Accuracy: {accuracy:.2%}")
    print(f"Errors: {dict(errors)}")
    
    # 保存结果
    save_results(results, output_file)
    
    return accuracy, errors

# 主程序
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="选择模型和数据类型")

    # 添加命令行参数
    parser.add_argument('--model_name', type=str, choices=["openai", "llama", "llama_FT", "llama_local", "qwen"],
                        default="llama_local", help="选择使用的模型名称")
    parser.add_argument('--data_type', type=str, choices=["clean", "noise", "sampled"],
                        default="sampled", help="选择数据类型")

    # 解析命令行参数
    args = parser.parse_args()

    for i in tqdm(range(1,11), desc="Processing"):
        test_file = f"/data1/maojinzhu/LLMCOG/data_process/StepGame/structured_data/{args.data_type}/qa{i}_test.json"
        output_file = f"/data1/maojinzhu/LLMCOG/data_process/test/stepgame/result/no_structure_{args.model_name}_{args.data_type}_evaluation{i}_results.json"  # 保存结果的文件路径
        
        test_data = load_test_data(test_file)
        
        if test_data:
            accuracy, errors = run_evaluation(test_data, output_file,args.model_name)
        else:
            print("No test data to evaluate.")
